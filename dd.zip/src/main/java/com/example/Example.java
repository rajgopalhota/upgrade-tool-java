package com.example;

import org.apache.commons.lang3.StringUtils;

public class Example {

    public static void main(String[] args) {
        System.out.println("Hello World");
    }

    public void regularMethod() {
        System.out.println("This is a regular method.");
    }

    /**
     * @deprecated Use {@link #newMethod()} instead.
     */
    @Deprecated
    public void deprecatedMethod() {
        System.out.println("This method is deprecated.");
    }

    public void newMethod() {
        System.out.println("This is a new method.");
    }

    public void useDeprecatedMethod() {
        deprecatedMethod(); // Calling deprecated method
    }
}
