import javax.annotation.PostConstruct;
import javax.xml.ws.WebServiceClient;

@WebServiceClient
public class Raja {

    @PostConstruct
    public void init() {
        System.out.println("Initialization logic here");
    }

    public void exampleMethod() {
        System.out.println("Example method logic here");
    }
}
