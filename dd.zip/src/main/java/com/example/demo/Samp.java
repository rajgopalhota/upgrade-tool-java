import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class Samp {

    public static void main(String[] args) {
        try {
            JAXBContext context = JAXBContext.newInstance(ExampleClass1.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.marshal(new ExampleClass1(), System.out);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}
