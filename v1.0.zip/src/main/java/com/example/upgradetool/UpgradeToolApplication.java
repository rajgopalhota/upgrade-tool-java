package com.example.upgradetool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpgradeToolApplication {
    public static void main(String[] args) {
        SpringApplication.run(UpgradeToolApplication.class, args);
    }
}
